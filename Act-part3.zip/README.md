# Act-part3
Ceci est l'activité proposée dans la troisième partie du cours Bootstrap.
Il fallait :
- Créer un menu de navigation fixe et rétractable sur petit écran
- Créer un carrousel avec 4 photos, des titres des boutons de navigations et des indicateurs de diapositives
- Le corps de page devait être construit selon un scrollspy fluide
- Et enfin le pied de page devait être centré sur une rangée.

L'exercice est à présent terminé il va pouvoir être évalué.
